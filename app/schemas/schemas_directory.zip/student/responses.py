# schemas/student/responses.py
from pydantic import BaseModel, EmailStr
from datetime import date, datetime
from typing import Optional
from user.base import UserBase

class StudentBaseResponse(UserBase):
    id: int
    form: str
    stream: Optional[str] = None
    date_of_birth: Optional[date] = None
    admission_number: str

    class Config:
        from_attributes = True

class StudentCreateResponse(StudentBaseResponse):
    created_at: datetime
    updated_at: Optional[datetime] = None

class StudentDetailResponse(StudentBaseResponse):
    pass

class StudentUpdateResponse(StudentBaseResponse):
    updated_at: datetime

class StudentListResponse(BaseModel):
    students: list[StudentBaseResponse]
    total_count: int

    class Config:
        from_attributes = True