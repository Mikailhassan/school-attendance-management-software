# app/schemas/teacher/__init__.py
from .base import TeacherBase
from .requests import (
    TeacherCreate,
    TeacherUpdate,
    TeacherRegistrationRequest
)
from .responses import TeacherResponse
